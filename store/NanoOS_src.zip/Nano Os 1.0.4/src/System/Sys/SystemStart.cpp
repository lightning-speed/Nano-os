void showStarting();


int startSystem(){
   showStarting();
}
void startShell();
void finalStart(){
  clearFullScreen();
  setScreenColor(0x07);
  startShell();
}
void load(){
  setCursorPosition(-1,-1);
  for(int i = 5;i<10;i++){
    printAt(36,2,(string)"Loading -",i);
    sleep(100);
    printAt(36,2,(string)"Loading /",i);
    sleep(100);
    printAt(36,2,(string)"Loading -",i);
    sleep(100);
     printAt(36,2,(string)"Loading \\",i);
    sleep(200);
  }
  for(int i = 10;i<16;i++){
    printAt(30,2,(string)"Getting Things Ready -",i);
    sleep(150);
    printAt(30,2,(string)"Getting Things Ready /",i);
    sleep(150);
    printAt(30,2,(string)"Getting Things Ready -",i);
    sleep(150);
     printAt(30,2,(string)"Getting Things Ready \\",i);
    sleep(200);
  }
  
  finalStart();
}
void showStarting(){
  clearScreen();
  setCursorPosition(0,0);
  print((string)"Starting...",0x07);
  sleep(1000);
  clearScreen();
  setScreenColor(0x0f);
  drawImage(32,7,splash);
  setCursorPosition(-1,-1);
  setY(18);
  printCenter((string)" Nano XOS\n",0x0f);
  printC('\n');
  printCenter((string)"By Krish",0x0c);
  load();
}