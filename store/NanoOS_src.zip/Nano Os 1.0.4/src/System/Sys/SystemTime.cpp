int readPit(void) {
	unsigned count = 0;
	cli();
	outportb(0x43,0b0000000);
	count = inportb(0x40);		
	count |= inportb(0x40)<<8;		
	return count;
}
void setPit(unsigned count) {
	cli();
	outportb(0x40,count&0xFF);		// Low byte
	outportb(0x40,(count&0xFF00)>>8);	// High byte
	return;
}
void sleep(int ms){
 for(int i = 0;i<ms/10;i++){
     for(int j  = 0;j<readPit();j++){}
 }
}