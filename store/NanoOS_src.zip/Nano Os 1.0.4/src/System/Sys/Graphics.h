void setScreenColor(int color){
  setDefaultColor(color);
  string vidmem = (string) 0xb8000;
  for(int i = 1;i<160*25;i+=2){
    if(vidmem[i]%16==0x0c)vidmem[i] = (color-(color%16))+0x0c;
    else vidmem[i] = color;
  }
}
void printCenter(string text,int color){
    int spaces = (80-length(text))/2;
    for(int i =0;i<spaces;i++){
        printC(' ');
    }
    print(text,color);
}
void  printAt(int xe,int ye,string text,int color){
  for(int i = 0;i<length(text);i++){
    setCharAt(xe+i,ye,text[i],color);
  }
}
void drawAt(int x,int y,int color){
  string a;
  a[0]=219;
  a[1]=a[0];
  printAt(x,y,a,color);
}
void clearFullScreen(){
  for(int i = 0;i<width*max(height,x);i+=2){
       vidmem[i]=0;
       vidmem[i+1]=0;
  }
  x = 0;
  y = 0;
}