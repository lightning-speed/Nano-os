#include "Commands.h"

int runCommand(string com){
  ret = 0;
  echo(com);
  colorS(com);
  run(com);
  if(equalS(com,(string)"pause",5))pauseC();
  com = (string)" ";
  return ret;
}
