int ret = 0;
void startShell();
void startHM();
void startB();
void exitB();
void pauseC(){
    cli();
    printW((string)"\nPress any key to continue...");
    readChar();
    ret = 1;
}
void echo(string a){
    if(a[0]=='e'&&a[1]=='c'&&a[2]=='h'&&a[3]=='o'){
        ret = 1;
        if(a[4]=='\0'||(a[4]==' '&&a[5]=='\0')){
            printW((string)"\nno string passed");
            return;
        }
        printC('\n');
        for(int i = 5;a[i]!=0;i++){
            printC(a[i]);
        }
    }
    
}

void colorS(string com){
  if(com[0]=='c'&&com[1]=='o'&&com[2]=='l'){
	  ret = 1;
     if(com[3]==0){printW((string)"  \ninvalid color");return;}
     if(com[4]<'0'||com[4]>'7'||com[4]==0){printW((string)"  \nset a integer from 0 to 7 in first argument");return;}
    sleep(10);
    if(com[4]=='0')setScreenColor(0x07);
    else if(com[4]=='1')setScreenColor(0x1f);
    else if(com[4]=='2')setScreenColor(0x27);
    else if(com[4]=='3')setScreenColor(0x38);
    else if(com[4]=='4')setScreenColor(0x47);
    else if(com[4]=='5')setScreenColor(0x57);
    else if(com[4]=='6')setScreenColor(0x67);
    else if(com[4]=='7')setScreenColor(0x7f);
  }
}
void run(string com){
 if(equalS(com,(string)"happiness-meter",14)){
     startHM();
     ret = 1;
 }
 if(equalS(com,(string)"bounce",6)){
     startB();
     ret = 1;
 }
 if(equalS(com,(string)"shell",5)){
     startShell();
     ret = 1;
 }
}
void upPressed(){
 
}
void downPressed(){

}
void escPressed(){
   
}