int null = 0;
typedef long long ll;
int sqrt(int sqr){
    for(int i = 1;i<31622;i++)if(i*i==sqr)return i;
    return null;
}
ll pow(int num,int power){
    ll ans = num;
    for(int i = 1;i<power;i++)ans*=num;
    return ans;
}
ll factorial(int fac){
    ll out = 1;
    for(int i = 1;i<=fac;i++)out *= i;
    return out;
}
int max(int a,int b){
    if(a>b)return a;
    else return b;
}
int min(int a,int b){
    if(a<b)return a;
    else return b;
}
 