typedef char * string;

int length(string in){
    int out = 0;
    for(int i = 0;in[i]!='\0';i++){
        out++;
    }
    return out;
}
string reverse(string in){
    string out = (string)"";
    int temp = 0;
    for(int i = length(in)-1;i>-1;i--){
        out[temp] = in[i];
        temp++;
    }
    return out;
}
string toString(int val){
    if(val==0)return (string)"0";
    string out = (string)"";
    int base = 10;
    char buf[32] = {0};
    int i = 30;
    for(; val && i ; --i, val /= base)
        buf[i] = "0123456789abcdef"[val % base];
    out = &buf[i+1];
    return out;
}
int parseInt(string a){
   int n = length(a);
   int out = 0;
   int ae = 1;
   for(int i = n-1;i>-1;i--){
        out+=(a[i]-'0')*ae;
        ae*=10;
   }
   return out;
}
bool  equal(string a,string b){
    for(int i = 0;i<(length(a)+length(b))/2;i++){
        if(a[i]!=b[i])return 0;
    }
    return 1;
}
bool  equalS(string a,string b,int mr){
    for(int i = 0;i<mr;i++){
        if(a[i]!=b[i])return 0;
    }
    return 1;
}
string till(string a,int e){
    a[(length(a)-1)-e]='\0';
    return a;
}
string join(string a,string b){
    string out = (string)"";
    int index = 0;
    for(int i = 0;a[i]!=0;i++){
        out[index] = a[i];
        index++;
    }
    for(int i = 0;b[i]!=0;i++){
        out[index] = b[i];
        index++;
    }
    out[index]=0;
    return out;
}
void setChar(string b,char a,int ind){
    b[ind] = a;
}
void eq(string a,string b){
    for(int i = 0;i<100;i++){
        a[i]=b[i];
    }
}
bool isRealSentence(string sent){
int ans = 0;
for(int i = 0;i<length(sent);i++)
  if(sent[i]!=' '&&sent[i]!=0)ans++;

  if(length(sent)-ans<=7&&ans>0&&length(sent)>0){
      return true;
  }
  else return false;
}