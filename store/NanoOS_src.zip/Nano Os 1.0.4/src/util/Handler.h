void SleepF(int ms){
    for(int i = 0;i<ms;i++){
        for(int j = 0;j<34444;j++){} 
    }
}
