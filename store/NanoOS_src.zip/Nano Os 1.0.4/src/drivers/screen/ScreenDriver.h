int x = 0;
int y = 0;
int index = 0;
int done = 0;
int width = 160,height = 25;
int defaultColor = 0x0f;
char * vidmem = (char *) 0xb8000;
bool canScroll = 0;
void setScreenColor(int color);
void setCursorPosition(int xe,int ye);
void updateCursor();
void setX(int xe){x = xe;}
void setY(int ye){y = ye;}
void scroll();

void printChar(char ch,int color){
    if(y>=24){scroll();}
    if(y>=25){scroll();scroll();scroll();scroll();}
    if(ch=='\b'&&done>1){
        x-=2;
        vidmem[(width*y)+x]=0;
        updateCursor();
        done--;
        return;
    }
    if(ch=='\n'){
        x = 0;
        y++;
        return;
    }
    if(ch!='\b'){
     vidmem[(width*y)+x]=ch;
     vidmem[(width*y)+x+1]=color;
     if(done<1&&vidmem[(width*y)+x]=='\b'){vidmem[(width*y)+x]=0;vidmem[(width*y)+x-1]=0;done-=2;return;}
     x+=2;
     if(x==width){
         y++;
         x = 0;
     }
      
     updateCursor();
     done++;
    }
}

void printC(char a){
    printChar(a,defaultColor);
}
void updateCursor(){
    unsigned temp;
    temp = y * 80 + (x/2);                                                      
    outportb(0x3D4, 14);                                                                
    outportb(0x3D5, temp >> 8);                                                         
    outportb(0x3D4, 15);                                                                
    outportb(0x3D5, temp);                                                              
}
void clearScreen(){
    for(int i = 0;i<(width*max(y,height))+100;i+=2){
        vidmem[i]='\0';
    }
    x = 0;
    y = 0;
}

void print(string k,int color){
  
    for(int i =0;i<length(k);i++){
       printChar(k[i],color);
    }
}
void printW(string k){
    
    for(int i =0;i<length(k);i++){
       printChar(k[i],defaultColor);
    }
}
void setCharAt(int xe,int ye,char ch,int color){
    xe*=2;
    vidmem[(width*ye)+xe]=ch;
    vidmem[(width*ye)+xe+1]=color;
}

void setColorAt(int xe,int ye,int color){
     xe*=2;
     vidmem[(width*ye)+xe+1]=color;
}
void setCursorPosition(int xe,int ye){
   unsigned temp;
    temp = ye * 80 + (xe/2);                                                      
    outportb(0x3D4, 14);                                                                
    outportb(0x3D5, temp >> 8);                                                         
    outportb(0x3D4, 15);                                                                
    outportb(0x3D5, temp);        
}
void setDefaultColor(int color){
    defaultColor = color;
}
void clearLine(int line){
    for(int i = 0;i<160;i++){
        vidmem[(width*line)+i]=0;
    }
}
void scroll(){
    string * lines;
    for(int i = 1;i<y+1;i++){
        for(int j = 0;j<160;j++){
            vidmem[(width*(i-1))+j] = vidmem[(width*i)+j];
        }
    }
    clearLine(y);
    y--;
      setScreenColor(defaultColor);
}