

void downPressed();
void upPressed();
void escPressed();
int getChar(){
    return inportb(0x60);
}
char readChar(){
    int runn = 1;
    char aer = null;
    char out = null;
    while(runn){
        if(inportb(0x64) & 0x1){
            aer = inportb(0x60);
           if(aer==0x01)escPressed();
           if(aer==0x0F)out='\t';
           if(aer==0x0C)out='-';
           if(aer==0x0D)out='=';
           if(aer==0x02)out='1';
           if(aer==0x03)out='2';
           if(aer==0x04)out='3';
           if(aer==0x05)out='4';
           if(aer==0x06)out='5';
           if(aer==0x07)out='6';
           if(aer==0x08)out='7';
           if(aer==0x09)out='8';
           if(aer==0x0A)out='9';
           if(aer==0x0B)out='0';
           if(aer==0x10)out='q';
           if(aer==0x11)out='w';
           if(aer==0x12)out='e';
           if(aer==0x13)out='r';
           if(aer==0x14)out='t';
           if(aer==0x15)out='y';
           if(aer==0x16)out='u';
           if(aer==0x17)out='i';
           if(aer==0x18)out='o';
           if(aer==0x19)out='p';
           if(aer==0x1a)out='[';
           if(aer==0x1b)out=']';
           if(aer==0x1c)out='\n';
           if(aer==0x0E)out='\b';
           if(aer==0x1e)out='a';
           if(aer==0x1f)out='s';
           if(aer==0x20)out='d';
           if(aer==0x21)out='f';
           if(aer==0x22)out='g';
           if(aer==0x23)out='h';
           if(aer==0x24)out='j';
           if(aer==0x25)out='k';
           if(aer==0x26)out='l';
           if(aer==0x27)out=';';
           if(aer==0x28)out=96;
           if(aer==0x29)out='`';
           if(aer==0x2b)out='\\';
           if(aer==0x2c)out='z';
           if(aer==0x2d)out='x';
           if(aer==0x2e)out='c';
           if(aer==0x2f)out='v';
           if(aer==0x30)out='b';
           if(aer==0x31)out='n';
           if(aer==0x32)out='m';
           if(aer==0x33)out=',';
           if(aer==0x34)out='.';
           if(aer==0x35)out='/';
           if(aer==0x39)out=' ';
           if(aer==0x48)upPressed();
           if(aer==0x50)downPressed();
           if(out!=null)runn=0;
        }
    }
    return out;
}
string readStr(){
     done = 1;
    string ou = (string)"";
    int ip = 1;
    int indx = 0;
    while(ip){
        ou[indx]=readChar();
          if(indx>0&&ou[indx]=='\b'){indx--;ou[indx]=0;printC('\b');indx--;}
        else{if(ou[indx]=='\n'){ip=0;ou[indx]=0;}
        else printChar(ou[indx],defaultColor);}
        indx++;
    }
    ou[indx-1]=0;
    return ou;
}